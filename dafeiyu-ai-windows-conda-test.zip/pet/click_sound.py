# -*- coding: utf-8 -*-
"""通用音效播放器与点击音效包支持。

播放路由（P1：winmm 直放）：
- .wav（含压缩音频的转码产物）优先走 ``pet.sound_winmm`` 的 waveOut 直放，
  全程不 import QtMultimedia——QtMultimedia 只要被 QSoundEffect 触碰一次，
  ffmpeg 后端（avcodec/avutil/avformat/MFCORE）就常驻进程（本机实测：最小
  进程放一个 wav 多 ~10MB，正式程序常驻约 40MB）；
- winmm 不可用（非 Windows/加载失败/打开设备失败/异常）时逐级回退既有
  QtMultimedia 路径（QSoundEffect + QMediaPlayer 池），行为与改动前逐位一致；
- 压缩音频未命中转码缓存时仍由 QAudioDecoder 转码 + QMediaPlayer 池出声
  （首次一次性代价），缓存落地后的每次播放都走 winmm；
- QtMultimedia 与系统播放器都不可用时静默失败并记录 warning，绝不使用系统
  提示音替代；非 Windows 平台在 QtMultimedia 缺失时回退到系统播放器。
"""
from __future__ import annotations

import logging
import hashlib
import os
import random
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import wave
from collections.abc import Sequence
from pathlib import Path
from typing import Any

from . import sound_winmm

log = logging.getLogger("pet.click_sound")

SUPPORTED_AUDIO_EXTENSIONS = {".wav", ".mp3", ".ogg", ".flac", ".m4a"}


class ClickSoundPool:
    """模块级单例音效池：收编全部 QtMultimedia 音效对象与缓存状态（A14）。

    所有权形态：本模块的全部可变播放状态（播放器/音频输出/音效/解码器/
    播放器池/导入失败标志/类缓存/时长缓存/配对状态）收进这一个对象，
    模块级公开函数只是委托给模块底部单例 ``_pool`` 的薄壳，调用点零改动。

    线程归属（owning thread）：
    - QtMultimedia 对象（QMediaPlayer / QAudioOutput / QSoundEffect /
      QAudioDecoder）只能在 GUI 线程创建与操作。本池的所有播放入口
      （play_* / warm_* / set_audio_volume / play_sound）都必须由 GUI
      线程调用；
    - 唯一例外是惰性 import 探测（qt_available / qt_multimedia_classes），
      只读模块导入结果、不触碰 Qt 对象，任何线程调用均安全；
    - 异步解码回调（QAudioDecoder.bufferReady/finished/error）由 Qt 事件
      循环在 GUI 线程派发，回调只操作本池在 GUI 线程创建的字典，单线程
      约束不破坏。

    生命周期：
    - 进程级单例，应用存活期间不复位——播放器/音效必须持久化，否则
      Python GC 会在播放开始前回收对象；
    - close()/clear() 语义：停止全部音效与播放器对象、清空对象缓存/
      播放器池/解码器注册表、复位播放游标与时长/配对缓存，并释放 winmm
      直放池（关设备/回收 header）。本池不拥有任何后台线程，close 无
      join/等待语义；调用方须在 GUI 线程调用。
      生产路径不调用（生命周期=进程），主要供测试隔离与模块热重载场景。

    winmm 直放（P1）：
    - ``winmm_pool()`` 惰性建一个 ``sound_winmm.WinmmSoundPool``；不可用时
      置 ``_winmm_unavailable`` 并永远回退 Qt 路径（只探一次，避免每次点击
      都去加载 DLL）。测试替换点是模块级 ``_new_winmm_pool``。
    """

    _PLAYER_POOL_SIZE = 4

    def __init__(self) -> None:
        self._qt_player = None
        self._qt_audio = None
        self._qt_effects: dict[str, Any] = {}
        self._qt_decoders: dict[str, Any] = {}
        self._qt_player_pool: list[tuple[Any, Any]] = []
        self._qt_player_index = 0
        self._qt_import_failed = False
        self._qt_classes: tuple[Any, ...] | None = None
        self._wav_duration_cache: dict[str, float] = {}
        self._click_pair_state: dict[tuple[str, str], dict[str, Any]] = {}
        self._winmm_pool: sound_winmm.WinmmSoundPool | None = None
        self._winmm_unavailable = False

    # ---------------- winmm 直放（GUI 线程，惰性） ----------------

    def winmm_pool(self) -> sound_winmm.WinmmSoundPool | None:
        """返回 winmm 直放池；不可用返回 None（探测结果缓存，只探一次）。"""
        if self._winmm_pool is not None:
            return self._winmm_pool
        if self._winmm_unavailable:
            return None
        pool = _new_winmm_pool()
        if pool is None or not pool.available():
            self._winmm_unavailable = True
            return None
        self._winmm_pool = pool
        return pool

    def play_with_winmm(self, path: Path, volume: float = 1.0) -> bool:
        """wav（含转码产物）优先走 waveOut 直放；返回 True = 已交给 winmm。

        路由与回退：
        - PCM16 wav → 直接喂；其它整型 PCM wav（8/24/32 位）→ 先落标准 wav
          缓存再喂缓存，本次与以后都不碰 QtMultimedia；
        - 压缩音频 → 命中转码缓存就走 winmm，未命中返回 False（交给既有 Qt
          解码/播放器池路径，首次一次性代价）；
        - 读不了（浮点/压缩 wav、多声道）/ winmm 不可用 / 设备打开或写入失败
          → 返回 False，逐级回退 Qt 路径，行为与改动前一致。
        """
        pool = self.winmm_pool()
        if pool is None:
            return False
        try:
            if path.suffix.lower() != ".wav":
                cache = _cache_path(path)
                if not cache.is_file():
                    return False
                return pool.play(cache, volume)
            return self._play_wav_with_winmm(pool, path, volume)
        except Exception:
            log.warning("winmm 直放异常，回退 Qt 路径: %s", path, exc_info=True)
            return False

    def _play_wav_with_winmm(self, pool: sound_winmm.WinmmSoundPool, path: Path, volume: float) -> bool:
        clip = sound_winmm.read_pcm16(path)
        if clip is not None and not clip.converted:
            # 绝大多数情况：PCM16 wav 直接喂，连缓存目录都不用碰
            return pool.play_clip(clip, volume)
        # 不标准 wav：先看转码缓存（可能是别的路线留下的），没有就自己落一份
        # 标准 wav 再走 winmm。QSoundEffect 只认整型 PCM，这里统一按标准 wav 走。
        cache = _cache_path(path)
        if cache.is_file():
            return pool.play(cache, volume)
        if clip is not None:
            if sound_winmm.write_pcm16_wav(clip, cache):
                return pool.play(cache, volume)
            return pool.play_clip(clip, volume)     # 写盘失败也别丢这一声
        # clip is None：`wave` 读不了（浮点/压缩/多声道 wav）→ 交给现有 Qt 路径，
        # 行为与改动前逐位一致。
        return False

    # ---------------- QtMultimedia 探测与对象创建（GUI 线程） ----------------

    def qt_available(self) -> bool:
        """惰性探测 QtMultimedia；失败只记一次日志。"""
        if self._qt_import_failed:
            return False
        try:
            from PySide6.QtMultimedia import QAudioDecoder, QAudioOutput, QMediaPlayer, QSoundEffect  # noqa: F401

            return True
        except Exception as exc:  # 打包遗漏/精简环境缺失时兜底
            self._qt_import_failed = True
            log.warning("QtMultimedia 不可用，音效将降级或静默失败: %s", exc)
            return False

    def qt_multimedia_classes(self):
        """Load multimedia classes lazily so headless/minimal installs can import this module."""
        if self._qt_classes is not None:
            return self._qt_classes
        if not self.qt_available():
            return None
        try:
            from PySide6.QtMultimedia import QAudioDecoder, QAudioFormat, QAudioOutput, QMediaPlayer, QSoundEffect
            self._qt_classes = (QAudioDecoder, QAudioFormat, QAudioOutput, QMediaPlayer, QSoundEffect)
            return self._qt_classes
        except Exception as exc:
            self._qt_import_failed = True
            log.warning("QtMultimedia 音效类不可用: %s", exc)
            return None

    def ensure_qt_player(self):
        """返回模块级单例播放器；不可用返回 None。

        播放器必须持久化，否则 Python GC 会在播放开始前回收对象。
        """
        if self._qt_player is not None:
            return self._qt_player
        if not self.qt_available():
            return None
        try:
            from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer

            self._qt_player = QMediaPlayer()
            self._qt_audio = QAudioOutput()
            self._qt_audio.setVolume(1.0)
            self._qt_player.setAudioOutput(self._qt_audio)
            return self._qt_player
        except Exception:
            log.exception("创建 QMediaPlayer 失败")
            return None

    def wav_duration(self, path: Path) -> float:
        """Read and cache duration from a decoded WAV header."""
        key = str(path.resolve())
        if key in self._wav_duration_cache:
            return self._wav_duration_cache[key]
        try:
            with wave.open(str(path), "rb") as source:
                duration = source.getnframes() / max(1, source.getframerate())
        except (OSError, EOFError, wave.Error):
            duration = 0.0
        self._wav_duration_cache[key] = duration
        return duration

    def effect_for(self, path: Path):
        classes = self.qt_multimedia_classes()
        if classes is None:
            return None
        key = str(path.resolve())
        effect = self._qt_effects.get(key)
        if effect is None:
            try:
                from PySide6.QtCore import QUrl
                effect = classes[4]()
                effect.setSource(QUrl.fromLocalFile(str(path)))
                self._qt_effects[key] = effect
            except Exception:
                log.exception("创建 QSoundEffect 失败: %s", path)
                return None
        return effect

    def play_with_effect(self, path: Path, volume: float) -> bool:
        effect = self.effect_for(path)
        if effect is None:
            return False
        key = str(path.resolve())
        if _effect_status_is_error(effect):
            # QSoundEffect 的错误态是粘滞的：status==Error 后 play() 变成静默
            # 空操作（不抛异常、不打日志），反复点击也不会有声——issue #116
            # 的"放一会儿再点就没声音"。实测唯一可靠的做法是丢弃旧对象重建
            # （重新 setSource 在部分后端上只会停在 Loading，仍不出声）。
            self._drop_effect(key)
            effect = self.effect_for(path)
            if effect is None:
                return False
            if _effect_status_is_error(effect):
                # 重建后仍错误 = 音频设备整体不可用：如实返回 False 并丢弃该
                # 对象，避免把一个坏对象留在缓存里永久污染后续点击。
                log.warning("音效设备不可用，本次播放跳过: %s", path)
                self._drop_effect(key)
                return False
        try:
            # 显式 stop 再 play：QSoundEffect 在部分 QtMultimedia/FFmpeg
            # 后端上对同一实例的第二次 play 可能不重启（只响第一次）。
            # 先 stop 可把内部播放状态复位，再 play 保证连点/试听每次都能响。
            stop = getattr(effect, "stop", None)
            if callable(stop):
                stop()
            set_loop_count = getattr(effect, "setLoopCount", None)
            if callable(set_loop_count):
                set_loop_count(1)
            effect.setVolume(volume)
            effect.play()
            return True
        except Exception:
            log.exception("QSoundEffect 播放失败: %s", path)
            return False

    def _drop_effect(self, key: str) -> None:
        """从缓存丢弃一个音效对象（错误态对象的唯一归宿）。"""
        effect = self._qt_effects.pop(key, None)
        if effect is None:
            return
        try:
            stop = getattr(effect, "stop", None)
            if callable(stop):
                stop()
        except Exception:
            pass

    def warm_player_pool(self) -> None:
        """预创建 QMediaPlayer 池，避免首次点击时初始化 QtMultimedia 造成卡顿。"""
        classes = self.qt_multimedia_classes()
        if classes is None:
            return
        try:
            if not self._qt_player_pool:
                if self._qt_player is not None and self._qt_audio is not None:
                    self._qt_player_pool.append((self._qt_player, self._qt_audio))
                for _ in range(self._PLAYER_POOL_SIZE):
                    if len(self._qt_player_pool) >= self._PLAYER_POOL_SIZE:
                        break
                    player, audio = classes[3](), classes[2]()
                    player.setAudioOutput(audio)
                    self._qt_player_pool.append((player, audio))
        except Exception:
            log.exception("预创建 QMediaPlayer 池失败")

    def player_pool_play(self, path: Path, volume: float) -> bool:
        classes = self.qt_multimedia_classes()
        if classes is None:
            return False
        try:
            self.warm_player_pool()
            if not self._qt_player_pool:
                return False
            player, audio = self._qt_player_pool[self._qt_player_index % len(self._qt_player_pool)]
            self._qt_player_index += 1
            audio.setVolume(volume)
            player.stop()
            from PySide6.QtCore import QUrl
            player.setSource(QUrl.fromLocalFile(str(path)))
            player.play()
            return True
        except Exception:
            log.exception("QMediaPlayer 池播放失败: %s", path)
            return False

    def decode_to_wav(self, source: Path, cache: Path, volume: float) -> bool:
        classes = self.qt_multimedia_classes()
        if classes is None:
            return False
        try:
            decoder = classes[0]()
            # 统一输出 16-bit PCM：源是浮点（如 mp3float）时直接写 WAV 会被
            # 当 PCM32 播放成噪音，QSoundEffect 也只认整型 PCM
            try:
                requested = classes[1]()
                requested.setSampleRate(48000)
                requested.setChannelCount(2)
                requested.setSampleFormat(classes[1].SampleFormat.Int16)
                decoder.setAudioFormat(requested)
            except Exception:
                log.warning("设置解码输出格式失败，按源格式解码: %s", source)
            state = {"chunks": [], "format": None}
            def on_buffer_ready():
                while decoder.bufferAvailable():
                    buffer = decoder.read()
                    state["format"] = buffer.format()
                    state["chunks"].append(_audio_buffer_bytes(buffer))
            def on_finished():
                self._qt_decoders.pop(str(source.resolve()), None)
                fmt = state["format"]
                if not fmt or not state["chunks"]:
                    log.warning("音频解码没有产生 PCM: %s", source)
                    return
                try:
                    sample_format = fmt.sampleFormat()
                    # PySide6 返回 SampleFormat 枚举（不能直接 int()），mock/旧版返回 int
                    sample_width = {1: 1, 2: 2, 3: 4, 4: 4}.get(
                        int(getattr(sample_format, "value", sample_format)), 2)
                    cache.parent.mkdir(parents=True, exist_ok=True)
                    with wave.open(str(cache), "wb") as out:
                        out.setnchannels(fmt.channelCount())
                        out.setsampwidth(sample_width)
                        out.setframerate(fmt.sampleRate())
                        out.writeframes(b"".join(state["chunks"]))
                except Exception:
                    log.exception("写入音效缓存失败: %s", cache)
            decoder.bufferReady.connect(on_buffer_ready)
            decoder.finished.connect(on_finished)
            error_signal = getattr(decoder, "error", None)
            if error_signal is not None and hasattr(error_signal, "connect"):
                error_signal.connect(lambda *_: log.warning("音频解码失败: %s", source))
            from PySide6.QtCore import QUrl
            decoder.setSource(QUrl.fromLocalFile(str(source)))
            self._qt_decoders[str(source.resolve())] = decoder
            decoder.start()
            return True
        except Exception:
            log.exception("启动音频解码失败: %s", source)
            return False

    def play_with_qt(self, path: Path, volume: float = 1.0) -> bool:
        if path.suffix.lower() == ".wav":
            return self.play_with_effect(path, volume)

        cache = _cache_path(path)
        if cache.is_file() and self.play_with_effect(cache, volume):
            return True

        # The decoder is asynchronous. Keep the first click audible through the
        # pool, while the finished callback warms the low-latency effect cache.
        key = str(path.resolve())
        if key not in self._qt_decoders and self.decode_to_wav(path, cache, volume):
            self.player_pool_play(path, volume)
            return True
        return self.player_pool_play(path, volume)

    def set_audio_volume(self, volume: float) -> float:
        """设置音频输出音量 (0.0..1.0)，返回 clamp 后的实际音量。

        winmm 可用时只设 waveOut 设备音量（与 QAudioOutput 的全局音量同义），
        不创建任何 QtMultimedia 对象；winmm 不可用时维持原有行为。
        """
        try:
            v = float(volume)
        except (TypeError, ValueError):
            v = 1.0
        v = max(0.0, min(1.0, v))
        pool = self.winmm_pool()
        if pool is not None:
            return pool.set_volume(v)
        self.ensure_qt_player()
        if self._qt_audio is not None:
            try:
                self._qt_audio.setVolume(v)
            except Exception:
                log.exception("设置音量失败")
        return v

    def warm_click_sound_effects(
        self,
        pack: dict | None,
        data_dir: Path | None = None,
        limit: int = 8,
    ) -> None:
        """预创建点击音效资源，避免首次点击时初始化音频后端造成卡顿。

        winmm 可用时（P1 关键路径）：**只预热 winmm 池**——为候选 wav 与已转码
        缓存各开满一个 waveOut 小池子（4 路句柄，waveOutOpen 实测 ~70ms/个，
        必须一次开满，否则快速连点会在 GUI 线程上逐个付开设备的钱），绝不创建
        QSoundEffect/QMediaPlayer，也绝不 import QtMultimedia（那正是 40MB 常驻
        ffmpeg 后端的来源）。此时未转码的压缩音频（如 duck mp3 首次使用）不预热：
        等第一次真的点击时才走 Qt 转码缓存路线（一次性代价，之后命中缓存全部走
        winmm）。

        winmm 不可用时维持原有 Qt 预热：WAV/已缓存音频预创建 QSoundEffect 并等待
        加载完成；未缓存的压缩音频启动异步解码并等待缓存生成；同时预创建
        QMediaPlayer 池。limit 限制自定义文件夹随机音效的预热数量。
        """
        pool = self.winmm_pool()
        if pool is not None:
            try:
                candidates = resolve_click_sound_candidates(pack, data_dir)[:limit]
                ready: list[Path] = []
                for path in candidates:
                    if path.suffix.lower() == ".wav":
                        ready.append(path)
                        continue
                    cache = _cache_path(path)
                    if cache.is_file():
                        ready.append(cache)
                pool.warm(ready)
            except Exception:
                log.exception("winmm 点击音效预热失败")
            return
        if not self.qt_available():
            return
        try:
            from PySide6.QtCore import QCoreApplication

            self.warm_player_pool()
            effects: list[Any] = []
            decoding: list[tuple[Path, Path, str]] = []
            candidates = resolve_click_sound_candidates(pack, data_dir)[:limit]
            for path in candidates:
                try:
                    if path.suffix.lower() == ".wav":
                        effect = self.effect_for(path)
                        if effect is not None:
                            effects.append(effect)
                    else:
                        cache = _cache_path(path)
                        if cache.is_file():
                            effect = self.effect_for(cache)
                            if effect is not None:
                                effects.append(effect)
                        else:
                            key = str(path.resolve())
                            if key not in self._qt_decoders:
                                self.decode_to_wav(path, cache, 0.0)
                            decoding.append((path, cache, key))
                except Exception:
                    log.exception("预热点击音效失败: %s", path)

            # 等待压缩音频解码出 WAV 缓存（异步，QCoreApplication 泵事件完成回调）
            deadline = time.monotonic() + 2.0
            while decoding and time.monotonic() < deadline:
                remaining: list[tuple[Path, Path, str]] = []
                for path, cache, key in decoding:
                    if cache.is_file():
                        effect = self.effect_for(cache)
                        if effect is not None:
                            effects.append(effect)
                    elif key in self._qt_decoders:
                        remaining.append((path, cache, key))
                    # key 不在 _qt_decoders 且没有缓存 = 解码失败/超时，跳过
                decoding = remaining
                if decoding:
                    QCoreApplication.processEvents()
                    time.sleep(0.005)

            # 等待 QSoundEffect 完成异步加载；未等待就播放会在事件循环里触发
            # 一次性加载/初始化，造成首次点击 Q 弹卡顿（实测可达数百 ms）。
            deadline = time.monotonic() + 2.0
            while effects and time.monotonic() < deadline:
                effects = [e for e in effects if not _effect_is_ready(e)]
                if effects:
                    QCoreApplication.processEvents()
                    time.sleep(0.005)
        except Exception:
            log.exception("点击音效预热失败")

    def play_press_sound(self, pair: tuple[Path, Path], volume: float = 1.0) -> bool:
        """Restart press and cancel any release currently playing."""
        press, release = pair
        if self.winmm_pool() is None:
            # Qt 路径：QSoundEffect 复用同一对象，必须显式 stop 上一次的 release，
            # 否则新 press 期间旧 release 还会继续响。
            # winmm 可用时这里刻意不碰 effect_for——它会 import QtMultimedia，
            # 而"没播过的 release"本来就被下面的 generation 门挡掉；已经在播的
            # release 会自然播完（小黄鸭尾巴，代价可接受），换来 40MB 不常驻。
            release_effect = self.effect_for(release)
            if release_effect is not None:
                try:
                    release_effect.stop()
                    release_effect.setLoopCount(1)
                    release_effect.setVolume(volume)
                except Exception:
                    pass
        state = self._click_pair_state.setdefault((str(press), str(release)), {})
        state["generation"] = int(state.get("generation", 0)) + 1
        state["press_started_at"] = time.monotonic()
        state["release_scheduled"] = False
        state["release_played"] = False
        return self.play_sound(press, volume=volume)

    def play_release_sound(
        self,
        pair: tuple[Path, Path], volume: float = 1.0, press_started_at: float | None = None,
    ) -> bool:
        """Play release immediately or at the last 100ms of the press sound."""
        press, release = pair
        started = press_started_at
        if started is None:
            started = self._click_pair_state.get((str(press), str(release)), {}).get("press_started_at")
        delay_ms = 0
        if started is not None:
            remaining = self.wav_duration(press) - (time.monotonic() - float(started))
            delay_ms = max(0, int(round((remaining - 0.100) * 1000)))
        state = self._click_pair_state.setdefault((str(press), str(release)), {})
        if state.get("release_scheduled") or state.get("release_played"):
            return False
        state["release_scheduled"] = bool(delay_ms)
        generation = int(state.get("generation", 0))
        def play() -> None:
            if int(state.get("generation", 0)) == generation:
                state["release_scheduled"] = False
                state["release_played"] = True
                self.play_sound(release, volume=volume)
        if delay_ms:
            try:
                from PySide6.QtCore import QTimer
            except Exception:
                return self.play_sound(release, volume=volume)
            QTimer.singleShot(delay_ms, play)
            return True
        play()
        return True

    def play_sound(self, path: Path | str, volume: float = 1.0) -> bool:
        """统一音频播放入口。返回 True 表示已提交播放。"""
        try:
            target = Path(path)
        except (TypeError, ValueError):
            return False
        if not target.is_file():
            return False
        # 取证日志：任何宠物侧发声都必须留痕（排查"莫名音效"用）
        try:
            import traceback
            caller = ""
            for frame in reversed(traceback.extract_stack()[-6:-1]):
                if "click_sound.py" not in frame.filename:
                    caller = f"{Path(frame.filename).name}:{frame.lineno}"
                    break
            log.info("播放音效 path=%s vol=%.2f caller=%s", target, volume, caller)
        except Exception:
            pass

        # 优先 winmm 直放（wav + 转码产物）：QtMultimedia 只要被触碰一次就会
        # 常驻 ffmpeg 后端（实测约 40MB）。不可用/失败时逐级回退 Qt 路径。
        if self.play_with_winmm(target, volume):
            return True

        # WAV and decoded short effects use QSoundEffect; compressed sources use
        # the decoder/cache path and a small player pool while warming up.
        if self.play_with_qt(target, volume):
            return True

        # 非 Windows 回退系统播放器
        if os.name != "nt":
            return _play_with_system_player(target)

        log.warning("QtMultimedia 不可用，音频播放跳过: %s", target)
        return False

    def play_click_sound(self, path: Path | str, volume: float = 1.0) -> bool:
        """兼容旧 API 的薄包装别名。"""
        return self.play_sound(path, volume=volume)

    # ---------------- 生命周期（GUI 线程） ----------------

    def clear(self) -> None:
        """释放全部 Qt 音效对象并复位池状态（GUI 线程调用）。

        停止并丢弃全部 QSoundEffect / QMediaPlayer / QAudioDecoder 引用，
        清空音效缓存、解码器注册表与播放器池，复位播放游标与时长/配对
        缓存；winmm 直放池一并释放（reset + 回收 header + waveOutClose）并
        复位"不可用"记忆，使下一次点击重新探测。保留 _qt_classes /
        _qt_import_failed 的惰性探测结果（不清除导入失败记忆，维持"失败只记
        一次日志"语义）。
        """
        winmm = self._winmm_pool
        self._winmm_pool = None
        self._winmm_unavailable = False
        if winmm is not None:
            try:
                winmm.clear()
            except Exception:
                log.debug("释放 winmm 直放池失败", exc_info=True)
        for effect in list(self._qt_effects.values()):
            try:
                effect.stop()
            except Exception:
                pass
        for decoder in list(self._qt_decoders.values()):
            try:
                decoder.stop()
            except Exception:
                pass
        for player, _audio in list(self._qt_player_pool):
            try:
                player.stop()
            except Exception:
                pass
        self._qt_effects.clear()
        self._qt_decoders.clear()
        self._qt_player_pool.clear()
        self._qt_player = None
        self._qt_audio = None
        self._qt_player_index = 0
        self._wav_duration_cache.clear()
        self._click_pair_state.clear()

    def close(self) -> None:
        """close 语义 = clear（本池不拥有后台线程，无 join/等待）。

        与 clear() 完全等价，仅为对称的生命周期命名；须在 GUI 线程调用。
        """
        self.clear()


# 模块级单例：全部音效状态与生命周期的唯一所有权对象。
_pool = ClickSoundPool()


# ---------------------------------------------------------------------------
# 模块级函数：公开 API 为薄壳（调用点零改动）；仅 _warm_player_pool 保留为
# 测试桩点（替换模块级名称），其余模块级 helper 属生产内部实现。
# ---------------------------------------------------------------------------

# 测试 seam：仅供测试注入，产品侧无调用
def _warm_player_pool() -> None:
    """预创建 QMediaPlayer 池，避免首次点击时初始化 QtMultimedia 造成卡顿。"""
    _pool.warm_player_pool()


def _new_winmm_pool() -> sound_winmm.WinmmSoundPool:
    """winmm 直放池工厂（模块级测试替换点：注入替身后端跑真实产品路由）。"""
    return sound_winmm.WinmmSoundPool()


def _decode_to_wav(source: Path, cache: Path, volume: float) -> bool:
    return _pool.decode_to_wav(source, cache, volume)


def set_audio_volume(volume: float) -> float:
    """设置音频输出音量 (0.0..1.0)，返回 clamp 后的实际音量。"""
    return _pool.set_audio_volume(volume)


def warm_click_sound_effects(
    pack: dict | None,
    data_dir: Path | None = None,
    limit: int = 8,
) -> None:
    """预创建点击音效对象，避免首次点击时初始化 QtMultimedia 造成卡顿。

    启动或切换音效包后调用：WAV/已缓存音频预创建 QSoundEffect 并等待加载完成；
    未缓存的压缩音频启动异步解码并等待缓存生成；同时预创建 QMediaPlayer 池。
    limit 用于限制自定义文件夹随机音效的预热数量，避免一次创建过多对象。
    """
    _pool.warm_click_sound_effects(pack, data_dir, limit)


def play_press_sound(pair: tuple[Path, Path], volume: float = 1.0) -> bool:
    """Restart press and cancel any release currently playing."""
    return _pool.play_press_sound(pair, volume)


def play_release_sound(
    pair: tuple[Path, Path], volume: float = 1.0, press_started_at: float | None = None,
) -> bool:
    """Play release immediately or at the last 100ms of the press sound."""
    return _pool.play_release_sound(pair, volume, press_started_at)


def play_sound(path: Path | str, volume: float = 1.0) -> bool:
    """统一音频播放入口。返回 True 表示已提交播放。"""
    return _pool.play_sound(path, volume)


def play_click_sound(path: Path | str, volume: float = 1.0) -> bool:
    """兼容旧 API 的薄包装别名。"""
    return _pool.play_click_sound(path, volume)


# ---------------------------------------------------------------------------
# 无状态的纯 helper 与解析 API（不触碰池状态，保持模块级）。
# ---------------------------------------------------------------------------

_SOUND_CACHE_DIR: Path | None = None


def _sound_cache_dir() -> Path:
    """音效缓存目录（进程内只解析一次）。

    ``QStandardPaths.writableLocation`` + ``mkdir`` 每次调用实测 0.25ms
    （``.scratch/windows-parity-20260926-a/fix-20260928-C1/bench-before.json``），
    而本函数在碰撞事件链上每个合格事件都会被 ``_cache_path`` 调一次（实机密集
    碰撞每秒最多 12.5 次）。QStandardPaths 的结果在进程内稳定（首个调用发生在
    ``QApplication`` 命名之后），故缓存；测试用 ``_reset_caches_for_tests()`` 复位。
    """
    global _SOUND_CACHE_DIR
    if _SOUND_CACHE_DIR is not None:
        return _SOUND_CACHE_DIR
    try:
        from PySide6.QtCore import QStandardPaths
        base = QStandardPaths.writableLocation(QStandardPaths.AppDataLocation)
    except Exception:
        base = ""
    root = Path(base) if base else Path(tempfile.gettempdir()) / "dsh-pet"
    result = root / "sounds_cache"
    result.mkdir(parents=True, exist_ok=True)
    _SOUND_CACHE_DIR = result
    return result


_DIGEST_MEMO: dict[tuple[str, int, int], str] = {}


def _cache_path(source: Path) -> Path:
    # 键用文件内容哈希而非 mtime：重新部署/复制素材会刷新 mtime 但内容没变，
    # 用 mtime 做键会让每次部署后首次点击都重转码并因此拉起 QtMultimedia
    # ffmpeg 后端（实机：+40~74MB 常驻，本机 DLL 取证实锤）。内容哈希经
    # (path, mtime, size) memo 只算一次——用户自定义音效包可能含大文件，
    # 不能每次点击都整读一遍（实审 P2-5）。读不到内容时退回 stat 键，
    # 绝不让缓存键计算炸掉播放路径。
    #
    # 键里的路径用 absolute() 而不是 resolve()：resolve 在 Windows 上是
    # GetFinalPathName 系统调用（实测 0.12ms/次，一次 _cache_path 付两次），
    # 而它只用于 memo 索引——摘要取的是内容哈希、落盘名只用 stem，换写法/相对
    # 路径引用同一文件最多多算一次内容哈希，输出逐位不变。碰撞事件链上每个合格
    # 事件要付 2 次 _cache_path（press+release），实机密集碰撞每秒最多 12.5 次。
    # 用 pathlib 的 absolute()：纯路径拼装、不碰文件系统，也不需要本模块的 os
    # 名字（既有用例把 ``click_sound.os`` 替成只带 name 的替身来伪造平台）。
    stat = source.stat()
    memo_key = (str(source.absolute()), stat.st_mtime_ns, stat.st_size)
    digest = _DIGEST_MEMO.get(memo_key)
    if digest is None:
        try:
            digest = hashlib.sha256(source.read_bytes()).hexdigest()[:20]
        except OSError:
            digest = hashlib.sha256(
                f"{memo_key[0]}:{memo_key[1]}:{memo_key[2]}".encode()
            ).hexdigest()[:20]
        if len(_DIGEST_MEMO) > 512:  # 卫生上限：memo 无界增长没意义
            _DIGEST_MEMO.clear()
        _DIGEST_MEMO[memo_key] = digest
    return _sound_cache_dir() / f"{source.stem}-{digest}.wav"


def _audio_buffer_bytes(buffer) -> bytes:
    data = buffer.data()
    try:
        return bytes(data)
    except (TypeError, ValueError):
        return bytes(data.constData())


def _effect_is_ready(effect: Any) -> bool:
    """判断 QSoundEffect 是否已完成异步加载；无 status 的测试替身视为就绪。"""
    status = getattr(effect, "status", None)
    if not callable(status):
        return True
    try:
        from PySide6.QtMultimedia import QSoundEffect

        return status() == QSoundEffect.Status.Ready
    except Exception:
        return True


def _effect_status_is_error(effect: Any) -> bool:
    """判断音效对象是否处于粘滞错误态（issue #116）。

    QSoundEffect 一旦进入 Error，play() 就是永久静默空操作，且 Qt 不会自愈；
    必须靠重建对象恢复。无 status 的测试替身/旧版本按"非错误"处理。
    """
    status = getattr(effect, "status", None)
    if not callable(status):
        return False
    try:
        from PySide6.QtMultimedia import QSoundEffect

        return status() == QSoundEffect.Status.Error
    except Exception:
        return False


#: 回退播放器的子进程句柄登记（#199）。不持有引用就没人 poll/wait，POSIX 上
#: 每个播完的 afplay/paplay 都会留成僵尸，Windows 上句柄也要等进程对象回收
#: ——点击音是高频动作，长时间挂着就是"调几次留几个"。
_SYSTEM_PLAYERS: list[subprocess.Popen] = []
# 登记表互斥：播放可能来自定时器/worker 线程，收割与登记并发时会互相吞掉
# （重新赋值的收割与 append 交错会让刚拉起的句柄凭空消失）。粒度只护列表读写。
_SYSTEM_PLAYERS_LOCK = threading.Lock()

#: 自回收周期（秒）。收割不能只挂在"下一次播放"上：点击音是"用户不点就不播"的
#: 动作，最后一批播放器退出之后没有任何后续调用，句柄/僵尸就一直留着。
#: 周期由登记触发（懒启动），登记表空了线程自行退出，不常驻。
_REAP_INTERVAL_S = 5.0
_REAPER: threading.Thread | None = None
_REAPER_LOCK = threading.Lock()


def _reap_system_players() -> None:
    """非阻塞收割已退出的回退播放器（POSIX 防僵尸，Windows 防句柄泄漏）。"""
    with _SYSTEM_PLAYERS_LOCK:
        alive = [proc for proc in _SYSTEM_PLAYERS if proc.poll() is None]
        _SYSTEM_PLAYERS[:] = alive


def _reaper_loop() -> None:
    """周期性收割；登记表空了就退出（不常驻线程）。

    退出前在 `_REAPER_LOCK` 内复查登记表：若有新播放刚登记完、还没走到
    `_ensure_reaper`，这里会看到非空而继续跑；反过来说，`_ensure_reaper`
    一定看得到 `_REAPER is None` 并另起一个——两条路都不会留下没人收割的表。
    """
    global _REAPER
    while True:
        time.sleep(_REAP_INTERVAL_S)
        _reap_system_players()
        with _REAPER_LOCK:
            with _SYSTEM_PLAYERS_LOCK:
                if _SYSTEM_PLAYERS:
                    continue
            _REAPER = None
            return


def _ensure_reaper() -> None:
    """确保有一个收割线程在跑（懒启动，已活着则不动）。

    **本函数不向调用方抛错**：起不了线程（RuntimeError：线程名额耗尽、解释器
    正在关闭）只记 warning 并返回，回收退到既有路径——每次
    `_play_with_system_player` 入口本来就会同步 reap 一次。异常穿出去的代价与
    收益完全不对等：`_ensure_reaper` 是被 `_play_with_system_player` 直接调的，
    而那里的 except 只接 OSError，RuntimeError 会继续穿到 `play_sound`（无 try）
    再穿进 GUI 调用栈——一次点击音换一次抛错，播放功能被回收机制拖累。

    失败时把 `_REAPER` 复位成 None：留着一个没起来的线程对象会让状态与事实不符，
    也会让下一次登记的"是否有收割线程"判断基于假象。
    """
    global _REAPER
    with _REAPER_LOCK:
        if _REAPER is not None and _REAPER.is_alive():
            return
        thread = threading.Thread(
            target=_reaper_loop, name="click-sound-player-reaper", daemon=True)
        try:
            thread.start()
        except RuntimeError:
            log.warning("播放器收割线程启动失败，回退到下次播放前收割登记项",
                        exc_info=True)
            _REAPER = None
            return
        _REAPER = thread


def _play_with_system_player(path: Path) -> bool:
    """非 Windows 回退：afplay / paplay / aplay。"""
    player = shutil.which("afplay") or shutil.which("paplay") or shutil.which("aplay")
    if not player:
        return False
    command = [player, str(path)]
    if Path(player).name == "aplay":
        command.insert(1, "-q")
    try:
        # 先收割上一批（非阻塞 poll，不卡 GUI 线程）再登记本次句柄；登记之后
        # 另起/唤活在跑的周期收割线程，**最后一批**退出时也有人回收（不靠下次播放）。
        _reap_system_players()
        proc = subprocess.Popen(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        with _SYSTEM_PLAYERS_LOCK:
            _SYSTEM_PLAYERS.append(proc)
        _ensure_reaper()
        return True
    except OSError:
        log.exception("系统播放器失败: %s", player)
        return False


def resolve_builtin_sound(sound_id: str) -> Path | None:
    """统一解析内置音频路径（支持源码目录与 PyInstaller sys._MEIPASS）。"""
    s_id = str(sound_id or "").strip()
    if s_id.startswith("builtin:"):
        s_id = s_id[len("builtin:"):]

    root = _sounds_root()
    sounds_dir = root / "assets" / "sounds"

    # Agent 音效别名或直接文件名
    agent_map = {
        "agent-start": sounds_dir / "agent" / "start.wav",
        "agent-done": sounds_dir / "agent" / "done.wav",
        "agent-error": sounds_dir / "agent" / "error.wav",
    }
    if s_id in agent_map:
        target = agent_map[s_id]
        return target if target.is_file() else None

    # 点击音效内置包
    if s_id == "default":
        target = sounds_dir / "click.wav"
        return target if target.is_file() else None

    return None


_duck_candidates_cache: dict[str, tuple[Path, ...]] = {}

#: 音源根目录缓存：键 = sys._MEIPASS 的当前值（None = 源码运行）
_SOUNDS_ROOT_MEMO: dict[object, Path] = {}


def _sounds_root() -> Path:
    """内置音源根目录（``sys._MEIPASS`` 或源码树根），每个 _MEIPASS 只 resolve 一次。

    ``Path(__file__).resolve().parents[1]`` 在 Windows 上是一次 GetFinalPathName
    系统调用（实测 0.22ms），而它此前是 ``getattr(sys, "_MEIPASS", <表达式>)``
    的**缺省实参**——即使打包运行（``_MEIPASS`` 存在）也会被求值，于是碰撞事件
    链上每个合格事件都白付一次（bench-before.json：``resolve_click_sound_candidates``
    0.27ms/次）。包路径在进程内不变，故缓存。
    """
    meipass = getattr(sys, "_MEIPASS", None)
    cached = _SOUNDS_ROOT_MEMO.get(meipass)
    if cached is None:
        cached = Path(meipass) if meipass else Path(__file__).resolve().parents[1]
        _SOUNDS_ROOT_MEMO[meipass] = cached
    return cached


def _reset_caches_for_tests() -> None:
    """仅测试用：清空模块级解析缓存（生产进程内缓存随包静态，无需失效）。"""
    _duck_candidates_cache.clear()
    _SOUNDS_ROOT_MEMO.clear()
    global _SOUND_CACHE_DIR
    _SOUND_CACHE_DIR = None


def _duck_candidates(duck_dir: Path) -> list[Path]:
    """内置小鸭包候选列表（带进程级缓存）。

    包内素材是打包资源，运行期不会变；但点击（window 每次按下/确认点击）与
    碰撞命中（sprite 世界 / 岛墙每次真撞）都会走到这里，
    不缓存就是 GUI 线程上每次命中一次目录扫描——碰撞瞬时尖峰来源之一。
    返回副本，调用方的改动不污染缓存。
    """
    key = str(duck_dir)
    cached = _duck_candidates_cache.get(key)
    if cached is not None:
        return list(cached)
    candidates: list[Path] = []
    if duck_dir.is_dir():
        candidates = sorted(
            p for p in duck_dir.iterdir()
            if p.is_file() and p.suffix.lower() in SUPPORTED_AUDIO_EXTENSIONS
        )
    _duck_candidates_cache[key] = tuple(candidates)
    return candidates


def resolve_click_sound_candidates(pack: dict | None, data_dir: Path | None = None) -> list[Path]:
    """根据点击音效包配置解析候选音频文件列表。"""
    pack = pack if isinstance(pack, dict) else {}
    kind = str(pack.get("kind") or "builtin").strip().lower()
    pack_id = str(pack.get("id") or "default").strip()
    path_str = str(pack.get("path") or "").strip()

    root = _sounds_root()
    sounds_dir = root / "assets" / "sounds"

    if kind == "builtin":
        if pack_id == "duck":
            return _duck_candidates(sounds_dir / "duck")
        # default builtin
        candidates = []
        if data_dir is not None:
            user_click = Path(data_dir) / "sounds" / "click.wav"
            if user_click.is_file():
                candidates.append(user_click)
        built_click = sounds_dir / "click.wav"
        if built_click.is_file():
            candidates.append(built_click)
        return candidates

    if kind == "file":
        if not path_str:
            return []
        p = Path(path_str).expanduser()
        if p.is_file() and p.suffix.lower() in SUPPORTED_AUDIO_EXTENSIONS:
            return [p]
        return []

    if kind == "folder":
        if not path_str:
            return []
        p = Path(path_str).expanduser()
        if p.is_dir():
            candidates = [
                f for f in p.iterdir()
                if f.is_file() and f.suffix.lower() in SUPPORTED_AUDIO_EXTENSIONS
            ]
            candidates.sort()
            return candidates[:128]
        return []

    return []


def resolve_click_sound_pair(pack: dict | None, data_dir: Path | None = None) -> tuple[Path, Path] | None:
    """Resolve the duck press/release pair, preferring decoded WAV caches."""
    pack = pack if isinstance(pack, dict) else {}
    if str(pack.get("kind") or "builtin").strip().lower() != "builtin":
        return None
    if str(pack.get("id") or "default").strip() != "duck":
        return None
    candidates = {path.stem.lower(): path for path in resolve_click_sound_candidates(pack, data_dir)}
    press, release = candidates.get("ya1"), candidates.get("ya2")
    if press is None or release is None:
        return None
    def cached(path: Path) -> Path:
        if path.suffix.lower() == ".wav":
            return path
        cache = _cache_path(path)
        if cache.is_file():
            return cache
        _decode_to_wav(path, cache, 0.0)
        return cache if cache.is_file() else path
    return cached(press), cached(release)


def choose_sound(candidates: Sequence[Path], rng: random.Random | None = None) -> Path | None:
    """从候选列表中挑选一个音频文件（支持传入 RNG 便于单测）。"""
    if not candidates:
        return None
    if len(candidates) == 1:
        return candidates[0]
    picker = rng if rng is not None else random
    return picker.choice(candidates)
