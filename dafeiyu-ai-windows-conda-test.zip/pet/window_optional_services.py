# -*- coding: utf-8 -*-
"""PetWindow 可选后台服务/效果控制器的懒装配 mixin（Phase 1 门控）。

把主动识屏 / Agent 联动 / 文件投喂 / 黄金回旋 / 边缘探头等“配置关闭就不构造”
的生命周期逻辑从 window.py 拆出，避免继续撑大 window.py（架构红线：行数预算）。
"""
from __future__ import annotations

import logging
from typing import Any

import shiboken6

from .window_effects import (
    begin_rotation,
    end_rotation,
    unrotate_point,
)


class WindowFeatureGateMixin:
    """供 PetWindow 混入的可选服务/效果懒装配能力。"""

    cfg: Any
    proactive_watcher: Any = None
    agent_link_manager: Any = None
    _file_eater: Any = None
    _file_interpret: Any = None
    # 桌宠隐藏时的气泡改道面（AppShell 注入 → 灵动岛反馈气泡），见
    # window_alerts.redirect_hidden_bubble；None = 维持原丢弃行为。
    hidden_bubble_redirect: Any = None
    # 桌宠隐藏期间灵动岛反馈面是否可用（AppShell 注入 → _island_chat_available）。
    island_feedback_available: Any = None

    def pause_agent_link_for_hide(self) -> None:
        """桌宠隐藏时的联动监视器处置（_pause_activity 委托）。

        灵动岛反馈面可用（hidden_chat 开 + 岛在）时**不暂停**：隐藏期间岛是
        交互面，DSH 联动事件仍需实时驱动岛反馈气泡（气泡经
        hidden_bubble_redirect 改道）。否则照旧 pause() 省电（原行为）。"""
        manager = getattr(self, "agent_link_manager", None)
        if manager is None:
            return
        island_feedback = getattr(self, "island_feedback_available", None)
        if callable(island_feedback):
            try:
                if island_feedback():
                    return
            except Exception:
                pass
        manager.pause()
    _broker_facade: Any = None
    _golden_spin: Any = None
    _edge_probe: Any = None
    _throw_egg: Any = None
    _music_lyric: Any = None

    # ------------------------------------------------------------ 判定
    def _proactive_wanted(self) -> bool:
        raw = self.cfg.get("proactive_screen", {})
        return bool((raw or {}).get("enabled", False))

    def _agent_link_wanted(self) -> bool:
        raw = self.cfg.get("agent_link", {})
        if not isinstance(raw, dict):
            return False
        for key in ("dsh", "claude", "cursor", "opencode"):
            if bool(raw.get(key, False)):
                return True
        return bool(raw.get("custom_agents"))

    # ------------------------------------------------------------ 懒创建
    def _ensure_proactive_watcher(self):
        """首次启用主动识屏时懒创建观察器；已存在则原样返回。"""
        if self.proactive_watcher is None:
            from .proactive import ProactiveScreenWatcher
            self.proactive_watcher = ProactiveScreenWatcher(self, self.cfg)
        return self.proactive_watcher

    def _ensure_agent_link_manager(self):
        """首次启用 Agent 联动时懒创建管理器；已存在则原样返回。"""
        if self.agent_link_manager is None:
            from .agent_link import AgentLinkManager
            self.agent_link_manager = AgentLinkManager(self, self.cfg)
        return self.agent_link_manager

    # ------------------------------------------------------------ 文件投喂
    def install_file_eater(self):
        """挂载“吃垃圾文件”拖放处理器（幂等，只对 PetWindow 实例调用）。"""
        if self._file_eater is None:
            from .file_eater import FileEaterDropHandler
            self._file_eater = FileEaterDropHandler(self)
        return self._file_eater

    # ------------------------------------------------------------ 文件解读
    def install_file_interpreter(self):
        """挂载拖文件解读控制器（幂等）并与投喂处理器互相接线。

        启用与否不再走 sync：offer() 每次实时读 file_interpret.enabled，
        设置页改动即时生效且无需同步钩子。
        """
        if self._file_interpret is None:
            from .file_interpret import FileInterpretController
            self._file_interpret = FileInterpretController(self)
        self.install_file_eater().interpret_offer = self._file_interpret.offer
        return self._file_interpret

    # ------------------------------------------------------------ 黄金回旋/边缘探头
    def _install_effect_services(self):
        """安装效果控制器（幂等）。PetWindow 构造末尾调用一次。"""
        if self._edge_probe is None:
            from .edge_probe import EdgeProbeController
            self._edge_probe = EdgeProbeController(self)
        if self._golden_spin is None:
            from .golden_spin import GoldenSpinController
            self._golden_spin = GoldenSpinController(self)
        if self._throw_egg is None:
            from .throw_egg import ThrowEggController
            self._throw_egg = ThrowEggController(self)
        return self

    # ------------------------------------------------------------ 歌词显示
    def install_music_lyric(self):
        """安装歌词显示控制器（幂等）。"""
        if self._music_lyric is None:
            from .music_lyric_controller import MusicLyricController
            self._music_lyric = MusicLyricController(self)
        return self._music_lyric

    def set_instrumental_playing(self, on: bool) -> None:
        """标记"当前放的是纯音乐"，让音乐自动唱歌不再触发。

        纯音乐没有可唱的句子。这里只置标志，真正的判定在
        ``window_alerts.check_music_sing``——在那里拦一道，比让歌词控制器
        每拍去"停止唱歌"要干净：否则两边一个关一个开，会持续打架。
        """
        self._instrumental_playing = bool(on)
        if on:
            self._music_sing_active = False

    def sync_music_lyric(self) -> None:
        """按配置启停歌词显示。

        不在这里判断窗口可见性：隐藏/显示是随时发生的，而控制器每次轮询都会
        自行检查可见性并空转。放在这里判断反而会漏掉"配置写入时窗口恰好隐藏"
        的情况，导致功能再也起不来。
        """
        enabled = bool(self.cfg.get("music_lyric_enabled", False))
        if not enabled and self._music_lyric is None:
            return  # 从未启用过：不为一个关着的功能白养一个定时器
        controller = self.install_music_lyric()
        controller.apply_lead()  # 提前量可能刚在设置里改过，先同步再启停
        controller.sync_enabled(enabled)

    def pause_music_lyric(self) -> None:
        """窗口隐藏：停掉歌词的 1s 轮询（`_effects_on_hidden` 调用）。

        控制器只停表不复位：``_on_tick`` 本就在不可见时短路，隐藏期间进度基准
        同样不推进，"停表"与"继续空转"的观感一致；复位反而会顺带清掉纯音乐
        标志。显示时由 ``_effects_on_shown`` → ``sync_music_lyric`` 按配置恢复。
        """
        controller = getattr(self, "_music_lyric", None)
        if controller is not None:
            controller.pause()

    def shutdown_music_lyric(self) -> None:
        """窗口关闭/会话结束：停掉歌词轮询（与 agent_link.shutdown 同处收口）。

        关闭后 ``win.close()`` 只隐藏不销毁，残留的 QTimer 会继续对半销毁
        窗口触发；会话结束（关机/注销）路径上更不该再每秒起一次
        ``asyncio.run`` + WinRT SMTC 调用（issue #111 的纪律）。
        """
        controller = getattr(self, "_music_lyric", None)
        if controller is not None:
            controller.shutdown()

    def trigger_golden_spin(self) -> None:
        """右键菜单入口：立即开始黄金回旋（边缘探头激活时不叠加）。"""
        self._install_effect_services()
        if self._edge_probe.active:
            return
        self._golden_spin.cancel_pending()
        self._golden_spin.start()

    def set_edge_probe_enabled(self, on: bool) -> None:
        """右键菜单/设置开关：写配置并同步控制器。"""
        self._install_effect_services()
        on = bool(on)
        self.cfg.set("edge_probe_enabled", on)
        self.cfg.save()
        self._edge_probe.set_enabled(on)

    # ------------------------------------------------------------ 窗口钩子
    def _effects_probe_active(self) -> bool:
        return bool(getattr(self, "_edge_probe", None) and self._edge_probe.active)

    def _effects_current_angle(self) -> float:
        if self._effects_probe_active():
            return float(self._edge_probe.current_angle_deg())
        egg = getattr(self, "_throw_egg", None)
        if egg is not None and egg.active:
            return float(egg.current_angle_deg())
        spin = getattr(self, "_golden_spin", None)
        if spin is not None and spin.active:
            return float(spin.current_angle_deg())
        return 0.0

    def _effects_paint(self, painter, rect) -> None:
        """paintEvent / _sync_mask 共用：进入旋转坐标系。"""
        angle = self._effects_current_angle()
        if abs(angle) > 1e-6:
            begin_rotation(painter, rect, angle)

    def _effects_paint_end(self, painter, rect) -> None:
        angle = self._effects_current_angle()
        if abs(angle) > 1e-6:
            end_rotation(painter, angle)

    def _effects_untransform(self, point, rect):
        """命中测试逆变换：把窗口逻辑点映射回未旋转坐标系。"""
        return unrotate_point(point, rect, self._effects_current_angle())

    def _effects_filter_switch(self, name: str) -> str:
        """边缘探头/彩蛋飞行会话期间只允许待机/转向动画；其它请求降级到随机待机。"""
        if not self._effects_probe_active():
            egg = getattr(self, "_throw_egg", None)
            if egg is None or not egg.active:
                return name
        idles = list(getattr(self, "idles", ()) or ())
        turns = list(getattr(self, "turns", ()) or ())
        if name in idles or name in turns or not idles:
            return name
        return self._pick(idles)

    def _effects_consume_click(self) -> bool:
        """点击事件先给效果层消费；边缘探头点击返回 True（普通点击不再触发）。"""
        if self._effects_probe_active():
            self._edge_probe.on_clicked()
            return True
        return False

    def _effects_route_click_golden_spin(self) -> bool:
        """点击触发黄金回旋路由。

        - 直连模式（golden_spin_direct）或角色无点击素材时：立即 spin_direct()
          并返回 True，调用方不再播放 Q 弹/点击素材。
        - armed 模式（有点击素材且未开启直连）：arm_after_click() 并返回 False，
          调用方继续播点击动画，播完后由 _effects_on_click_anim_finished 接续。
        - 未开启“点击触发黄金回旋”时返回 False，调用方走普通点击链路。
        """
        if self._effects_probe_active():
            return False
        if not bool(self.cfg.get("golden_spin_on_click", False)):
            return False
        spin = getattr(self, "_golden_spin", None)
        if spin is None:
            return False
        direct = bool(self.cfg.get("golden_spin_direct", False))
        has_clips = bool(getattr(self, "clicks", None))
        if not direct and has_clips:
            spin.arm_after_click()
            return False
        spin.cancel_pending()
        spin.spin_direct()
        return True

    def _effects_on_click_anim_finished(self) -> None:
        spin = getattr(self, "_golden_spin", None)
        if spin is not None:
            spin.consume_click_finished()

    def _effects_on_drag_started(self) -> None:
        if self._effects_probe_active():
            self._edge_probe.on_drag_started()

    def _effects_on_release(self, was_dragging: bool) -> None:
        edge = getattr(self, "_edge_probe", None)
        if edge is not None:
            edge.on_release(bool(was_dragging))

    def _effects_on_hidden(self) -> None:
        edge = getattr(self, "_edge_probe", None)
        if edge is not None:
            edge.pause()
        spin = getattr(self, "_golden_spin", None)
        if spin is not None:
            spin.cancel()
        # 歌词轮询同属"不可见即零消耗"：隐藏期间停表，显示时由
        # _effects_on_shown → sync_music_lyric 按配置恢复。
        self.pause_music_lyric()

    def _effects_on_shown(self) -> None:
        edge = getattr(self, "_edge_probe", None)
        if edge is not None:
            edge.resume()
        # 首次显示时若配置已开也在这里装上（sync_music_lyric 幂等）；
        # 隐藏期间用户可能刚改过开关，故恢复也要重读配置而不是无条件 start。
        self.sync_music_lyric()

    def match_shutdown(self) -> None:
        """会话结束（Windows 关机/注销）收口本窗（issue #111）。

        必须由 ``WM_QUERYENDSESSION`` 这一层触发、而不是等 ``closeEvent``：
        关机窗口期内本进程每多活一秒、动画链每多切一次，都可能 CreateProcess
        新的 ffmpeg；新进程在已拆除的会话里会以 0xc0000142 弹窗阻塞关机。

        步骤与理由（**顺序不可颠倒**）：
        1. 先 ``_pause_activity()``：停当前 reader、停全部活动 timer、
           ``pause_warm()``、清预测预热。必须**先**做——它自身在 ``_closing``
           置位后是短路 no-op（那是给「已关闭/会话结束后迟到的 hideEvent」用的），
           先置 ``_closing`` 会让停机一步都做不到；
        2. 再置 ``_closing``（closeEvent 同款生命周期守卫）——帧驱动的动画切换
           （_on_frame/移动/自动移动）、``_resume_activity`` 与预测预热都会据此
           短路，reader 自此不会被复活；
        3. ``shutdown_music_lyric()``：歌词的 1s 轮询会在 GUI 线程起
           ``asyncio.run`` + WinRT SMTC 调用，关机窗口期内同样不该再有生产者；
        4. ``detach_decode_sessions()`` 收尾本窗共享解码 broker 会话（发布/订阅
           钩子摘除），与 closeEvent 的收尾保持一致。

        不调 ``close()``：会话结束时进程随即退出，closeEvent 的写盘/销毁链既非
        必需又会拖长清理窗口。每步独立兜异常（半销毁窗口不得阻断其余收口）。
        """
        try:
            if not shiboken6.isValid(self):
                return  # C++ 侧已销毁的半死窗口：无可收口
        except Exception:
            pass
        # 与 hideEvent 同款置位「窗口不可见」暂停态：会话结束后没有任何可见效果，
        # 该标志还让 _on_frame/_on_switch_retry_timeout 等入口一并短路（双保险）。
        self._hidden_paused = True
        try:
            pause = getattr(self, "_pause_activity", None)
            if callable(pause):
                pause()
        except Exception:
            logging.getLogger(__name__).debug("会话结束时暂停窗口活动失败", exc_info=True)
        self._closing = True
        try:
            self.shutdown_music_lyric()
        except Exception:
            logging.getLogger(__name__).debug("会话结束时停止歌词轮询失败", exc_info=True)
        try:
            detach = getattr(self, "detach_decode_sessions", None)
            if callable(detach):
                detach()
        except Exception:
            logging.getLogger(__name__).debug("会话结束时收尾解码会话失败", exc_info=True)

    def _effects_skip_turn_facing(self) -> bool:
        return self._effects_probe_active()

    # ------------------------------------------------------------ 同步
    def sync_optional_services(self) -> None:
        """设置刷新公共入口：按配置懒装配/同步主动识屏、Agent 联动与效果控制器。"""
        if self._proactive_wanted():
            self._ensure_proactive_watcher().apply_config()
        elif self.proactive_watcher is not None:
            self.proactive_watcher.apply_config()
        if self._agent_link_wanted():
            self._ensure_agent_link_manager().apply_config()
        elif self.agent_link_manager is not None:
            self.agent_link_manager.apply_config()
        self._install_effect_services()
        self._edge_probe.set_enabled(bool(self.cfg.get("edge_probe_enabled", False)))
        self.sync_music_lyric()
